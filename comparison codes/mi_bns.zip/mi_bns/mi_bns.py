
import numpy as np
from sklearn.metrics import confusion_matrix
from scipy.stats import norm
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer 
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from scipy.sparse import csr_matrix
from scipy import io
import sklearn.metrics as metrics
import math
import scipy

'''
FILE DEPENDENCIES :-

mi_scores.txt  | Global feature scores using mi ranking
bns_scores.txt | Global feature scores using bns ranking
x_train.mtx    | 
x_test.mtx     |
y_train.txt    |
y_test.txt     |
''' 



###################################################################
def delete_row_csr(mat, i):
    if not isinstance(mat, scipy.sparse.csr_matrix):
        raise ValueError("works only for CSR format -- use .tocsr() first")
    n = mat.indptr[i+1] - mat.indptr[i]
    if n > 0:
        mat.data[mat.indptr[i]:-n] = mat.data[mat.indptr[i+1]:]
        mat.data = mat.data[:-n]
        mat.indices[mat.indptr[i]:-n] = mat.indices[mat.indptr[i+1]:]
        mat.indices = mat.indices[:-n]
    mat.indptr[i:-1] = mat.indptr[i+1:]
    mat.indptr[i:] -= n
    mat.indptr = mat.indptr[:-1]
    mat._shape = (mat._shape[0]-1, mat._shape[1])

def get_contingency(feature, category):
    fc1 = 0
    fc2 = 0
    fc3 = 0
    fc4 = 0
    doc_matrix = term_freq.toarray()
    docs = doc_matrix.shape[0]

    for doc in range(docs):
        if (doc_matrix[doc][feature] != 0) & (y_train[doc] == category):
            fc1 = fc1 + 1
        elif (doc_matrix[doc][feature] != 0) & (y_train[doc] != category):
            fc2 = fc2 + 1
        elif (doc_matrix[doc][feature] == 0) & (y_train[doc] == category):
            fc3 = fc3 + 1
        elif (doc_matrix[doc][feature] == 0) & (y_train[doc] != category):
            fc4 = fc4 + 1
    return np.array([[fc1, fc2], [fc3, fc4]])

def N_category(category):
    count = 0
    for i in xrange(len(y_train)):
        if category == y_train[i]:
            count = count + 1
    return count

def score_matrix():
    bns_matrix =  np.zeros(shape=(len(features)))
    mi_matrix =  np.zeros(shape=(len(features)))
    
    ''' THIS ORDEAL IS OVA
    for f in features:
        for c in categories:
            print " c = ",c," f = ",f
            bns_score,mi_score = score(f,c)
            Nc = N0 if c==0 else N1
            bns_matrix[f] = bns_matrix[f] + ( ( 1.0*Nc / d) * bns_score)
            mi_matrix[f] = mi_matrix[f] + ( (1.0*Nc/ d) * mi_score )
        fl.write(str(f)+"\t"+str(bns_matrix[f])+"\t"+str(mi_matrix[f])+"\n")
    '''

    bns_matrix =  np.loadtxt("bns_scores.txt")
    mi_matrix  =  np.loadtxt("mi_scores.txt")

    return bns_matrix , mi_matrix


def kbest(kbest):
    bns_rank,mi_rank = score_matrix()
    
    #Obtain sorted index list of feature-rank list in reverse with first kbest elements
    #  :- Gives the kbest features in descending order
    bns_sorted = bns_rank.argsort()[::-1][:kbest]
    mi_sorted = mi_rank.argsort()[::-1][:kbest]
    #np.savetxt("bns_kbest.txt",bns_sorted,delimiter=',')
    #np.savetxt("mi_kbest.txt",mi_sorted,delimiter=',')
    
    return bns_sorted[:kbest], mi_sorted[:kbest]

'''
    for i in xrange(kbest):
        bns_features.append(features[ ind[i] ])
        mi_features.append(features[ ind[i] ])
    return bns_features, mi_features
'''


def score(feature,category):
    Nfc = get_contingency(feature,category)
    Nf = Nfc[0][0] + Nfc[0][1]
    Nc = N0 if category==0 else N1
    Nnc = d - Nc
    Nnf = d - Nf
    print "NFC[",feature,",",category,"] = ",Nfc[0][0],",",Nfc[0][1],",",Nfc[1][0],",",Nfc[1][1]
    
    norm1 = 0.0
    norm2 = 0.0

    if Nfc[0][0] == 0:
        norm1 = norm.ppf(1.0/10000)
    elif Nfc[0][0] == Nc:
        norm1 = norm.ppf(1.0 - (1.0/10000))
    else:
        norm1 = norm.ppf(1.0 * Nfc[0][0] / Nc)

    if Nfc[0][1] == 0:
        norm2 = norm.ppf(1.0/10000)
    elif Nfc[0][1] == Nnc:
        norm2 = norm.ppf(1.0 - (1.0/10000))
    else:
        norm2 = norm.ppf(1.0 * Nfc[0][1] / Nnc) 

    bns_score = abs(norm1 - norm2)
    

    term1 = 0 if Nfc[0][0] == 0 else ( ( 1.0 * Nfc[0][0] / d) * np.log( ( 1.0 * d * Nfc[0][0] ) / (Nf * Nc )))

    term2 = 0 if Nfc[0][1] == 0 else (  ( 1.0 * Nfc[0][1] / d) * np.log( ( 1.0 * d * Nfc[0][1] ) / (Nf * Nnc )))

    term3 = 0 if Nfc[1][0] == 0 else ( ( 1.0 * Nfc[1][0] / d) * np.log( ( 1.0 * d * Nfc[1][0] ) / (Nnf * Nc )))

    term4 = 0 if Nfc[1][0] == 0 else ( ( 1.0 * Nfc[1][1] / d) * np.log( ( 1.0 * d * Nfc[1][1] ) / (Nnf * Nnc )))

    mi_score = term1 + term2 + term3 + term4

    return bns_score,mi_score

'''
def mi_transform():
    X_tr = X_train.transpose().tocsr()
    X_ts = X_test.transpose().tocsr()
    i = X_tr.shape[1] - 1
    []
    print(i)
    k = 0
    while i >= 0:
        i = i - 1
        if i in bns_features:
            k = k + 1
            continue
        else:
            delete_row_csr(X_tr,i)
            delete_row_csr(X_ts,i)
    print("k")
    print(k)
    print(len(bns_features))
    print(X_tr.shape)
    print(X_ts.shape)
    return X_tr.transpose().tocsr(), X_ts.transpose().tocsr()    

def bns_transform():
    X_tr = X_train.transpose().tocsr()
    print "bns before transform len of xtr", X_tr.shape
    print "len of bns features: ",len(bns_features)
    X_ts = X_test.transpose().tocsr()
    
    i=n

    while i > 0:
        i = i - 1
        if i in bns_features:
            continue
        else:
            delete_row_csr(X_tr,i)
            delete_row_csr(X_ts,i)
    return X_tr.transpose().tocsr(), X_ts.transpose().tocsr()
'''



'''
PROGRAM STARTS HERE
'''
#fl = open('scores.txt',"w")


#LOAD PREVIOUSLY CALCULATED SCORES AND TF-IDF DATA 
y_train = np.loadtxt("ytrain.txt")
categories = np.unique(y_train)
category_names = ['soc.religion.christian','comp.graphics']
#print categories
y_test1=np.loadtxt("ytest.txt")
y_test2=np.loadtxt("ytest.txt")

X_train1 = io.mmread("xtrain.mtx").tocsr()
X_test1 =io.mmread("xtest.mtx").tocsr()
X_train1 = io.mmread("xtrain.mtx").tocsr()
#X_train = io.mmread("xtrain.mtx").tocsr()

X_train2 = io.mmread("xtrain.mtx").tocsr()
X_test2 =io.mmread("xtest.mtx").tocsr()

#term_freq = io.mmread("term_freq_train.mtx")

#print "len of ytrain: ",len(y_train)
# mat 1 is rows: features columns: docs
#mat1 = X_train.todense()
# mat 1 is rows: docs columns: features
#mat2 = mat1.T
#n , d = X_train.shape[::-1]
d,n = X_train1.shape
print "Number of features before feature selection: ",n
print

features = range(0,n)
docs = set()
#X = mat2.tolist() 

N0 = N_category(0) 
N1 = d - N0

# Get the KBest features using bns score and mi score
bns_features, mi_features = kbest(10000)

#print(bns_features[:10])
#print(mi_features[:10])
# MUTUAL INFORMATION
print "Selecting 10,000 best features for BNS"
print

#lists have some issues being searched
bns_features_s = set(bns_features)
mi_features_s = set(mi_features)

#Transformation loop to delete non-kbest features from data set for BNS
X_tr1 = X_train1.transpose().tocsr()
X_ts1 = X_test1.transpose().tocsr()

i = X_tr1.shape[0]
k = 0
while i > 0:
    i = i -1
    
    if i in bns_features_s:
        k = k + 1
        continue
    else:
        delete_row_csr(X_tr1, i)
        delete_row_csr(X_ts1, i)
#print(k)

bns_xtrain = X_tr1.transpose().tocsr()
bns_xtest = X_ts1.transpose().tocsr()


print "Selecting 10,000 best features for MI"
print
#
#Transformation loop to delete non-kbest features from data set for MI
#
X_tr2 = X_train2.transpose().tocsr()
X_ts2 = X_test2.transpose().tocsr()

#io.mmwrite("xtr1.mtx",X_tr1)


i = X_tr2.shape[0]
k = 0
while i > 0:
    i = i -1
    
    if i in mi_features_s:
        k = k + 1
        continue
    else:
        delete_row_csr(X_tr2, i)
        delete_row_csr(X_ts2, i)
#io.mmwrite("xtr2.mtx",X_tr1)


mi_xtrain = X_tr2.transpose().tocsr()
mi_xtest = X_ts2.transpose().tocsr()

#
#Create classifiers and obtain prediction for Mutual Information
#
clf1   = MultinomialNB()
clf1.fit(mi_xtrain, y_train)
mi_pred = clf1.predict(mi_xtest)

#np.savetxt("mi_xtrain.txt",mi_xtrain.todense(),delimiter=',')

np.savetxt("mi_pred.txt",mi_pred,delimiter=',')
print "Metrics for mutual information:"
print(metrics.classification_report(y_test1, mi_pred,target_names=category_names))

#
#Create classifiers and obtain prediction for Binormal Separation
#
clf2   = MultinomialNB()
clf2.fit(bns_xtrain, y_train)
bns_pred = clf2.predict(bns_xtest)
#np.savetxt("bns_pred.txt",bns_pred,delimiter=',')
#np.savetxt("bns_xtrain.txt",bns_xtrain.todense(),delimiter=',')
print "Metrics for bi-normal separation:"

print(metrics.classification_report(y_test2, bns_pred,target_names=category_names))
